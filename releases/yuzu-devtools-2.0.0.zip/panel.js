!function(t){var e={};function n(r){if(e[r])return e[r].exports;var s=e[r]={i:r,l:!1,exports:{}};return t[r].call(s.exports,s,s.exports,n),s.l=!0,s.exports}n.m=t,n.c=e,n.d=function(t,e,r){n.o(t,e)||Object.defineProperty(t,e,{enumerable:!0,get:r})},n.r=function(t){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})},n.t=function(t,e){if(1&e&&(t=n(t)),8&e)return t;if(4&e&&"object"==typeof t&&t&&t.__esModule)return t;var r=Object.create(null);if(n.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:t}),2&e&&"string"!=typeof t)for(var s in t)n.d(r,s,function(e){return t[e]}.bind(null,s));return r},n.n=function(t){var e=t&&t.__esModule?function(){return t.default}:function(){return t};return n.d(e,"a",e),e},n.o=function(t,e){return Object.prototype.hasOwnProperty.call(t,e)},n.p="",n(n.s=76)}([function(t,e){t.exports=function(t){return null!=t&&"object"==typeof t}},function(t,e,n){var r=n(8)(Object,"create");t.exports=r},function(t,e,n){var r=n(38);t.exports=function(t,e){for(var n=t.length;n--;)if(r(t[n][0],e))return n;return-1}},function(t,e,n){var r=n(44);t.exports=function(t,e){var n=t.__data__;return r(e)?n["string"==typeof e?"string":"hash"]:n.map}},function(t,e){t.exports='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"></path></svg>'},function(t,e,n){var r=n(6),s=n(16),i=n(17),o="[object Null]",a="[object Undefined]",c=r?r.toStringTag:void 0;t.exports=function(t){return null==t?void 0===t?a:o:c&&c in Object(t)?s(t):i(t)}},function(t,e,n){var r=n(7).Symbol;t.exports=r},function(t,e,n){var r=n(14),s="object"==typeof self&&self&&self.Object===Object&&self,i=r||s||Function("return this")();t.exports=i},function(t,e,n){var r=n(26),s=n(30);t.exports=function(t,e){var n=s(t,e);return r(n)?n:void 0}},function(t,e,n){var r=n(20),s=n(59),i=n(65),o=n(73),a=i(function(t,e){return o(t)?r(t,s(e,1,o,!0)):[]});t.exports=a},function(t,e,n){var r=n(5),s=n(11),i="[object AsyncFunction]",o="[object Function]",a="[object GeneratorFunction]",c="[object Proxy]";t.exports=function(t){if(!s(t))return!1;var e=r(t);return e==o||e==a||e==i||e==c}},function(t,e){t.exports=function(t){var e=typeof t;return null!=t&&("object"==e||"function"==e)}},function(t,e){t.exports=function(t){return t}},function(t,e,n){var r=n(5),s=n(18),i=n(0),o="[object Object]",a=Function.prototype,c=Object.prototype,l=a.toString,u=c.hasOwnProperty,h=l.call(Object);t.exports=function(t){if(!i(t)||r(t)!=o)return!1;var e=s(t);if(null===e)return!0;var n=u.call(e,"constructor")&&e.constructor;return"function"==typeof n&&n instanceof n&&l.call(n)==h}},function(t,e,n){(function(e){var n="object"==typeof e&&e&&e.Object===Object&&e;t.exports=n}).call(this,n(15))},function(t,e){var n;n=function(){return this}();try{n=n||new Function("return this")()}catch(t){"object"==typeof window&&(n=window)}t.exports=n},function(t,e,n){var r=n(6),s=Object.prototype,i=s.hasOwnProperty,o=s.toString,a=r?r.toStringTag:void 0;t.exports=function(t){var e=i.call(t,a),n=t[a];try{t[a]=void 0;var r=!0}catch(t){}var s=o.call(t);return r&&(e?t[a]=n:delete t[a]),s}},function(t,e){var n=Object.prototype.toString;t.exports=function(t){return n.call(t)}},function(t,e,n){var r=n(19)(Object.getPrototypeOf,Object);t.exports=r},function(t,e){t.exports=function(t,e){return function(n){return t(e(n))}}},function(t,e,n){var r=n(21),s=n(50),i=n(55),o=n(56),a=n(57),c=n(58),l=200;t.exports=function(t,e,n,u){var h=-1,d=s,p=!0,f=t.length,g=[],m=e.length;if(!f)return g;n&&(e=o(e,a(n))),u?(d=i,p=!1):e.length>=l&&(d=c,p=!1,e=new r(e));t:for(;++h<f;){var v=t[h],y=null==n?v:n(v);if(v=u||0!==v?v:0,p&&y==y){for(var b=m;b--;)if(e[b]===y)continue t;g.push(v)}else d(e,y,u)||g.push(v)}return g}},function(t,e,n){var r=n(22),s=n(48),i=n(49);function o(t){var e=-1,n=null==t?0:t.length;for(this.__data__=new r;++e<n;)this.add(t[e])}o.prototype.add=o.prototype.push=s,o.prototype.has=i,t.exports=o},function(t,e,n){var r=n(23),s=n(43),i=n(45),o=n(46),a=n(47);function c(t){var e=-1,n=null==t?0:t.length;for(this.clear();++e<n;){var r=t[e];this.set(r[0],r[1])}}c.prototype.clear=r,c.prototype.delete=s,c.prototype.get=i,c.prototype.has=o,c.prototype.set=a,t.exports=c},function(t,e,n){var r=n(24),s=n(35),i=n(42);t.exports=function(){this.size=0,this.__data__={hash:new r,map:new(i||s),string:new r}}},function(t,e,n){var r=n(25),s=n(31),i=n(32),o=n(33),a=n(34);function c(t){var e=-1,n=null==t?0:t.length;for(this.clear();++e<n;){var r=t[e];this.set(r[0],r[1])}}c.prototype.clear=r,c.prototype.delete=s,c.prototype.get=i,c.prototype.has=o,c.prototype.set=a,t.exports=c},function(t,e,n){var r=n(1);t.exports=function(){this.__data__=r?r(null):{},this.size=0}},function(t,e,n){var r=n(10),s=n(27),i=n(11),o=n(29),a=/^\[object .+?Constructor\]$/,c=Function.prototype,l=Object.prototype,u=c.toString,h=l.hasOwnProperty,d=RegExp("^"+u.call(h).replace(/[\\^$.*+?()[\]{}|]/g,"\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,"$1.*?")+"$");t.exports=function(t){return!(!i(t)||s(t))&&(r(t)?d:a).test(o(t))}},function(t,e,n){var r,s=n(28),i=(r=/[^.]+$/.exec(s&&s.keys&&s.keys.IE_PROTO||""))?"Symbol(src)_1."+r:"";t.exports=function(t){return!!i&&i in t}},function(t,e,n){var r=n(7)["__core-js_shared__"];t.exports=r},function(t,e){var n=Function.prototype.toString;t.exports=function(t){if(null!=t){try{return n.call(t)}catch(t){}try{return t+""}catch(t){}}return""}},function(t,e){t.exports=function(t,e){return null==t?void 0:t[e]}},function(t,e){t.exports=function(t){var e=this.has(t)&&delete this.__data__[t];return this.size-=e?1:0,e}},function(t,e,n){var r=n(1),s="__lodash_hash_undefined__",i=Object.prototype.hasOwnProperty;t.exports=function(t){var e=this.__data__;if(r){var n=e[t];return n===s?void 0:n}return i.call(e,t)?e[t]:void 0}},function(t,e,n){var r=n(1),s=Object.prototype.hasOwnProperty;t.exports=function(t){var e=this.__data__;return r?void 0!==e[t]:s.call(e,t)}},function(t,e,n){var r=n(1),s="__lodash_hash_undefined__";t.exports=function(t,e){var n=this.__data__;return this.size+=this.has(t)?0:1,n[t]=r&&void 0===e?s:e,this}},function(t,e,n){var r=n(36),s=n(37),i=n(39),o=n(40),a=n(41);function c(t){var e=-1,n=null==t?0:t.length;for(this.clear();++e<n;){var r=t[e];this.set(r[0],r[1])}}c.prototype.clear=r,c.prototype.delete=s,c.prototype.get=i,c.prototype.has=o,c.prototype.set=a,t.exports=c},function(t,e){t.exports=function(){this.__data__=[],this.size=0}},function(t,e,n){var r=n(2),s=Array.prototype.splice;t.exports=function(t){var e=this.__data__,n=r(e,t);return!(n<0||(n==e.length-1?e.pop():s.call(e,n,1),--this.size,0))}},function(t,e){t.exports=function(t,e){return t===e||t!=t&&e!=e}},function(t,e,n){var r=n(2);t.exports=function(t){var e=this.__data__,n=r(e,t);return n<0?void 0:e[n][1]}},function(t,e,n){var r=n(2);t.exports=function(t){return r(this.__data__,t)>-1}},function(t,e,n){var r=n(2);t.exports=function(t,e){var n=this.__data__,s=r(n,t);return s<0?(++this.size,n.push([t,e])):n[s][1]=e,this}},function(t,e,n){var r=n(8)(n(7),"Map");t.exports=r},function(t,e,n){var r=n(3);t.exports=function(t){var e=r(this,t).delete(t);return this.size-=e?1:0,e}},function(t,e){t.exports=function(t){var e=typeof t;return"string"==e||"number"==e||"symbol"==e||"boolean"==e?"__proto__"!==t:null===t}},function(t,e,n){var r=n(3);t.exports=function(t){return r(this,t).get(t)}},function(t,e,n){var r=n(3);t.exports=function(t){return r(this,t).has(t)}},function(t,e,n){var r=n(3);t.exports=function(t,e){var n=r(this,t),s=n.size;return n.set(t,e),this.size+=n.size==s?0:1,this}},function(t,e){var n="__lodash_hash_undefined__";t.exports=function(t){return this.__data__.set(t,n),this}},function(t,e){t.exports=function(t){return this.__data__.has(t)}},function(t,e,n){var r=n(51);t.exports=function(t,e){return!(null==t||!t.length)&&r(t,e,0)>-1}},function(t,e,n){var r=n(52),s=n(53),i=n(54);t.exports=function(t,e,n){return e==e?i(t,e,n):r(t,s,n)}},function(t,e){t.exports=function(t,e,n,r){for(var s=t.length,i=n+(r?1:-1);r?i--:++i<s;)if(e(t[i],i,t))return i;return-1}},function(t,e){t.exports=function(t){return t!=t}},function(t,e){t.exports=function(t,e,n){for(var r=n-1,s=t.length;++r<s;)if(t[r]===e)return r;return-1}},function(t,e){t.exports=function(t,e,n){for(var r=-1,s=null==t?0:t.length;++r<s;)if(n(e,t[r]))return!0;return!1}},function(t,e){t.exports=function(t,e){for(var n=-1,r=null==t?0:t.length,s=Array(r);++n<r;)s[n]=e(t[n],n,t);return s}},function(t,e){t.exports=function(t){return function(e){return t(e)}}},function(t,e){t.exports=function(t,e){return t.has(e)}},function(t,e,n){var r=n(60),s=n(61);t.exports=function t(e,n,i,o,a){var c=-1,l=e.length;for(i||(i=s),a||(a=[]);++c<l;){var u=e[c];n>0&&i(u)?n>1?t(u,n-1,i,o,a):r(a,u):o||(a[a.length]=u)}return a}},function(t,e){t.exports=function(t,e){for(var n=-1,r=e.length,s=t.length;++n<r;)t[s+n]=e[n];return t}},function(t,e,n){var r=n(6),s=n(62),i=n(64),o=r?r.isConcatSpreadable:void 0;t.exports=function(t){return i(t)||s(t)||!!(o&&t&&t[o])}},function(t,e,n){var r=n(63),s=n(0),i=Object.prototype,o=i.hasOwnProperty,a=i.propertyIsEnumerable,c=r(function(){return arguments}())?r:function(t){return s(t)&&o.call(t,"callee")&&!a.call(t,"callee")};t.exports=c},function(t,e,n){var r=n(5),s=n(0),i="[object Arguments]";t.exports=function(t){return s(t)&&r(t)==i}},function(t,e){var n=Array.isArray;t.exports=n},function(t,e,n){var r=n(12),s=n(66),i=n(68);t.exports=function(t,e){return i(s(t,e,r),t+"")}},function(t,e,n){var r=n(67),s=Math.max;t.exports=function(t,e,n){return e=s(void 0===e?t.length-1:e,0),function(){for(var i=arguments,o=-1,a=s(i.length-e,0),c=Array(a);++o<a;)c[o]=i[e+o];o=-1;for(var l=Array(e+1);++o<e;)l[o]=i[o];return l[e]=n(c),r(t,this,l)}}},function(t,e){t.exports=function(t,e,n){switch(n.length){case 0:return t.call(e);case 1:return t.call(e,n[0]);case 2:return t.call(e,n[0],n[1]);case 3:return t.call(e,n[0],n[1],n[2])}return t.apply(e,n)}},function(t,e,n){var r=n(69),s=n(72)(r);t.exports=s},function(t,e,n){var r=n(70),s=n(71),i=n(12),o=s?function(t,e){return s(t,"toString",{configurable:!0,enumerable:!1,value:r(e),writable:!0})}:i;t.exports=o},function(t,e){t.exports=function(t){return function(){return t}}},function(t,e,n){var r=n(8),s=function(){try{var t=r(Object,"defineProperty");return t({},"",{}),t}catch(t){}}();t.exports=s},function(t,e){var n=800,r=16,s=Date.now;t.exports=function(t){var e=0,i=0;return function(){var o=s(),a=r-(o-i);if(i=o,a>0){if(++e>=n)return arguments[0]}else e=0;return t.apply(void 0,arguments)}}},function(t,e,n){var r=n(74),s=n(0);t.exports=function(t){return s(t)&&r(t)}},function(t,e,n){var r=n(10),s=n(75);t.exports=function(t){return null!=t&&s(t.length)&&!r(t)}},function(t,e){var n=9007199254740991;t.exports=function(t){return"number"==typeof t&&t>-1&&t%1==0&&t<=n}},function(t,e,n){"use strict";n.r(e);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const r=new WeakMap,s=t=>(...e)=>{const n=t(...e);return r.set(n,!0),n},i=t=>"function"==typeof t&&r.has(t),o=void 0!==window.customElements&&void 0!==window.customElements.polyfillWrapFlushCallback,a=(t,e,n=null,r=null)=>{let s=e;for(;s!==n;){const e=s.nextSibling;t.insertBefore(s,r),s=e}},c=(t,e,n=null)=>{let r=e;for(;r!==n;){const e=r.nextSibling;t.removeChild(r),r=e}},l={},u={},h=`{{lit-${String(Math.random()).slice(2)}}}`,d=`\x3c!--${h}--\x3e`,p=new RegExp(`${h}|${d}`),f="$lit$";class g{constructor(t,e){this.parts=[],this.element=e;let n=-1,r=0;const s=[],i=e=>{const o=e.content,a=document.createTreeWalker(o,133,null,!1);let c=0;for(;a.nextNode();){n++;const e=a.currentNode;if(1===e.nodeType){if(e.hasAttributes()){const s=e.attributes;let i=0;for(let t=0;t<s.length;t++)s[t].value.indexOf(h)>=0&&i++;for(;i-- >0;){const s=t.strings[r],i=y.exec(s)[2],o=i.toLowerCase()+f,a=e.getAttribute(o).split(p);this.parts.push({type:"attribute",index:n,name:i,strings:a}),e.removeAttribute(o),r+=a.length-1}}"TEMPLATE"===e.tagName&&i(e)}else if(3===e.nodeType){const t=e.data;if(t.indexOf(h)>=0){const i=e.parentNode,o=t.split(p),a=o.length-1;for(let t=0;t<a;t++)i.insertBefore(""===o[t]?v():document.createTextNode(o[t]),e),this.parts.push({type:"node",index:++n});""===o[a]?(i.insertBefore(v(),e),s.push(e)):e.data=o[a],r+=a}}else if(8===e.nodeType)if(e.data===h){const t=e.parentNode;null!==e.previousSibling&&n!==c||(n++,t.insertBefore(v(),e)),c=n,this.parts.push({type:"node",index:n}),null===e.nextSibling?e.data="":(s.push(e),n--),r++}else{let t=-1;for(;-1!==(t=e.data.indexOf(h,t+1));)this.parts.push({type:"node",index:-1})}}};i(e);for(const t of s)t.parentNode.removeChild(t)}}const m=t=>-1!==t.index,v=()=>document.createComment(""),y=/([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F \x09\x0a\x0c\x0d"'>=\/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/;
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
class b{constructor(t,e,n){this._parts=[],this.template=t,this.processor=e,this.options=n}update(t){let e=0;for(const n of this._parts)void 0!==n&&n.setValue(t[e]),e++;for(const t of this._parts)void 0!==t&&t.commit()}_clone(){const t=o?this.template.element.content.cloneNode(!0):document.importNode(this.template.element.content,!0),e=this.template.parts;let n=0,r=0;const s=t=>{const i=document.createTreeWalker(t,133,null,!1);let o=i.nextNode();for(;n<e.length&&null!==o;){const t=e[n];if(m(t))if(r===t.index){if("node"===t.type){const t=this.processor.handleTextExpression(this.options);t.insertAfterNode(o.previousSibling),this._parts.push(t)}else this._parts.push(...this.processor.handleAttributeExpressions(o,t.name,t.strings,this.options));n++}else r++,"TEMPLATE"===o.nodeName&&s(o.content),o=i.nextNode();else this._parts.push(void 0),n++}};return s(t),o&&(document.adoptNode(t),customElements.upgrade(t)),t}}
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */class w{constructor(t,e,n,r){this.strings=t,this.values=e,this.type=n,this.processor=r}getHTML(){const t=this.strings.length-1;let e="";for(let n=0;n<t;n++){const t=this.strings[n],r=y.exec(t);e+=r?t.substr(0,r.index)+r[1]+r[2]+f+r[3]+h:t+d}return e+this.strings[t]}getTemplateElement(){const t=document.createElement("template");return t.innerHTML=this.getHTML(),t}}
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const x=t=>null===t||!("object"==typeof t||"function"==typeof t);class k{constructor(t,e,n){this.dirty=!0,this.element=t,this.name=e,this.strings=n,this.parts=[];for(let t=0;t<n.length-1;t++)this.parts[t]=this._createPart()}_createPart(){return new _(this)}_getValue(){const t=this.strings,e=t.length-1;let n="";for(let r=0;r<e;r++){n+=t[r];const e=this.parts[r];if(void 0!==e){const t=e.value;if(null!=t&&(Array.isArray(t)||"string"!=typeof t&&t[Symbol.iterator]))for(const e of t)n+="string"==typeof e?e:String(e);else n+="string"==typeof t?t:String(t)}}return n+=t[e]}commit(){this.dirty&&(this.dirty=!1,this.element.setAttribute(this.name,this._getValue()))}}class _{constructor(t){this.value=void 0,this.committer=t}setValue(t){t===l||x(t)&&t===this.value||(this.value=t,i(t)||(this.committer.dirty=!0))}commit(){for(;i(this.value);){const t=this.value;this.value=l,t(this)}this.value!==l&&this.committer.commit()}}class S{constructor(t){this.value=void 0,this._pendingValue=void 0,this.options=t}appendInto(t){this.startNode=t.appendChild(v()),this.endNode=t.appendChild(v())}insertAfterNode(t){this.startNode=t,this.endNode=t.nextSibling}appendIntoPart(t){t._insert(this.startNode=v()),t._insert(this.endNode=v())}insertAfterPart(t){t._insert(this.startNode=v()),this.endNode=t.endNode,t.endNode=this.startNode}setValue(t){this._pendingValue=t}commit(){for(;i(this._pendingValue);){const t=this._pendingValue;this._pendingValue=l,t(this)}const t=this._pendingValue;t!==l&&(x(t)?t!==this.value&&this._commitText(t):t instanceof w?this._commitTemplateResult(t):t instanceof Node?this._commitNode(t):Array.isArray(t)||t[Symbol.iterator]?this._commitIterable(t):t===u?(this.value=u,this.clear()):this._commitText(t))}_insert(t){this.endNode.parentNode.insertBefore(t,this.endNode)}_commitNode(t){this.value!==t&&(this.clear(),this._insert(t),this.value=t)}_commitText(t){const e=this.startNode.nextSibling;t=null==t?"":t,e===this.endNode.previousSibling&&3===e.nodeType?e.data=t:this._commitNode(document.createTextNode("string"==typeof t?t:String(t))),this.value=t}_commitTemplateResult(t){const e=this.options.templateFactory(t);if(this.value instanceof b&&this.value.template===e)this.value.update(t.values);else{const n=new b(e,t.processor,this.options),r=n._clone();n.update(t.values),this._commitNode(r),this.value=n}}_commitIterable(t){Array.isArray(this.value)||(this.value=[],this.clear());const e=this.value;let n,r=0;for(const s of t)void 0===(n=e[r])&&(n=new S(this.options),e.push(n),0===r?n.appendIntoPart(this):n.insertAfterPart(e[r-1])),n.setValue(s),n.commit(),r++;r<e.length&&(e.length=r,this.clear(n&&n.endNode))}clear(t=this.startNode){c(this.startNode.parentNode,t.nextSibling,this.endNode)}}class z{constructor(t,e,n){if(this.value=void 0,this._pendingValue=void 0,2!==n.length||""!==n[0]||""!==n[1])throw new Error("Boolean attributes can only contain a single expression");this.element=t,this.name=e,this.strings=n}setValue(t){this._pendingValue=t}commit(){for(;i(this._pendingValue);){const t=this._pendingValue;this._pendingValue=l,t(this)}if(this._pendingValue===l)return;const t=!!this._pendingValue;this.value!==t&&(t?this.element.setAttribute(this.name,""):this.element.removeAttribute(this.name)),this.value=t,this._pendingValue=l}}class $ extends k{constructor(t,e,n){super(t,e,n),this.single=2===n.length&&""===n[0]&&""===n[1]}_createPart(){return new E(this)}_getValue(){return this.single?this.parts[0].value:super._getValue()}commit(){this.dirty&&(this.dirty=!1,this.element[this.name]=this._getValue())}}class E extends _{}let T=!1;try{const t={get capture(){return T=!0,!1}};window.addEventListener("test",t,t),window.removeEventListener("test",t,t)}catch(t){}class O{constructor(t,e,n){this.value=void 0,this._pendingValue=void 0,this.element=t,this.eventName=e,this.eventContext=n,this._boundHandleEvent=(t=>this.handleEvent(t))}setValue(t){this._pendingValue=t}commit(){for(;i(this._pendingValue);){const t=this._pendingValue;this._pendingValue=l,t(this)}if(this._pendingValue===l)return;const t=this._pendingValue,e=this.value,n=null==t||null!=e&&(t.capture!==e.capture||t.once!==e.once||t.passive!==e.passive),r=null!=t&&(null==e||n);n&&this.element.removeEventListener(this.eventName,this._boundHandleEvent,this._options),r&&(this._options=N(t),this.element.addEventListener(this.eventName,this._boundHandleEvent,this._options)),this.value=t,this._pendingValue=l}handleEvent(t){"function"==typeof this.value?this.value.call(this.eventContext||this.element,t):this.value.handleEvent(t)}}const N=t=>t&&(T?{capture:t.capture,passive:t.passive,once:t.once}:t.capture);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */const C=new class{handleAttributeExpressions(t,e,n,r){const s=e[0];return"."===s?new $(t,e.slice(1),n).parts:"@"===s?[new O(t,e.slice(1),r.eventContext)]:"?"===s?[new z(t,e.slice(1),n)]:new k(t,e,n).parts}handleTextExpression(t){return new S(t)}};
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */function P(t){let e=G.get(t.type);void 0===e&&(e={stringsArray:new WeakMap,keyString:new Map},G.set(t.type,e));let n=e.stringsArray.get(t.strings);if(void 0!==n)return n;const r=t.strings.join(h);return void 0===(n=e.keyString.get(r))&&(n=new g(t,t.getTemplateElement()),e.keyString.set(r,n)),e.stringsArray.set(t.strings,n),n}const G=new Map,A=new WeakMap,j=(t,e,n)=>{let r=A.get(e);void 0===r&&(c(e,e.firstChild),A.set(e,r=new S(Object.assign({templateFactory:P},n))),r.appendInto(e)),r.setValue(t),r.commit()};
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
(window.litHtmlVersions||(window.litHtmlVersions=[])).push("1.0.0");const M=(t,...e)=>new w(t,e,"html",C),V="function"==typeof Symbol?Symbol.for:t=>t,D=V("haunted.phase"),L=V("haunted.hook"),I=V("haunted.update"),W=V("haunted.commit"),R=V("haunted.effects"),F=V("haunted.context");let H,B=0;function q(t){H=t}function U(){H=null,B=0}const Q=Promise.resolve().then.bind(Promise.resolve());function J(){let t,e=[];function n(){t=null;let n=e;e=[];for(var r=0,s=n.length;r<s;r++)n[r]()}return function(r){e.push(r),null==t&&(t=Q(n))}}const Y=J(),K=J();class X{constructor(t,e,n){this.renderer=t,this.frag=e,this.host=n||e,this[L]=new Map,this[D]=null,this._updateQueued=!1}update(){this._updateQueued||(Y(()=>{let t=this.handlePhase(I);K(()=>{this.handlePhase(W,t),this[R]&&K(()=>{this.handlePhase(R)})}),this._updateQueued=!1}),this._updateQueued=!0)}handlePhase(t,e){switch(this[D]=t,t){case W:return this.commit(e);case I:return this.render();case R:return this.runEffects(R)}this[D]=null}commit(t){j(t,this.frag),this.runEffects(W)}render(){q(this);let t=this.args?this.renderer.apply(this.host,this.args):this.renderer.call(this.host,this.host);return U(),t}runEffects(t){let e=this[t];if(e){q(this);for(let t of e)t.call(this);U()}}teardown(){this[L].forEach(t=>{"function"==typeof t.teardown&&t.teardown()})}}function Z(t,e=HTMLElement,n={useShadowDOM:!0}){class r extends e{static get observedAttributes(){return t.observedAttributes||[]}constructor(){super(),!1===n.useShadowDOM?this._container=new X(t,this):(this.attachShadow({mode:"open"}),this._container=new X(t,this.shadowRoot,this))}connectedCallback(){this._container.update()}disconnectedCallback(){this._container.teardown()}attributeChangedCallback(t,e,n){let r=""===n||n;Reflect.set(this,function(t=""){return-1===t.indexOf("-")?t.toLowerCase():t.toLowerCase().split("-").reduce((t,e)=>t?t+e.charAt(0).toUpperCase()+e.slice(1):e,"")}(t),r)}}const s=new Proxy(e.prototype,{set(t,e,n,r){let s;return e in t&&Reflect.set(t,e,n),s="symbol"==typeof e||"_"===e[0]?{enumerable:!0,configurable:!0,writable:!0,value:n}:function(t){let e=t;return Object.freeze({enumerable:!0,configurable:!0,get:()=>e,set(t){e=t,this._container.update()}})}(n),Object.defineProperty(r,e,s),s.set&&s.set.call(r,n),!0}});return Object.setPrototypeOf(r.prototype,s),r}class tt{constructor(t,e){this.id=t,this.el=e}}function et(t,...e){let n=function(){let t=B;return B++,t}(),r=H[L],s=r.get(n);return s||(s=new t(n,H,...e),r.set(n,s)),s.update(...e)}function nt(t){return et.bind(null,t)}const rt=nt(class extends tt{constructor(t,e,n,r){super(t,e),this.value=n(),this.values=r}update(t,e){return this.hasChanged(e)&&(this.values=e,this.value=t()),this.value}hasChanged(t){return t.some((t,e)=>this.values[e]!==t)}}),st=(t,e)=>rt(()=>t,e);const it=nt(class extends tt{constructor(t,e){super(t,e),this.values=!1,function(t,e){R in t||(t[R]=[]),t[R].push(e)}(e,this)}update(t,e){this.callback=t,this.lastValues=this.values,this.values=e}call(){this.values?this.hasChanged()&&this.run():this.run()}run(){this.teardown(),this._teardown=this.callback.call(this.el)}teardown(){this._teardown&&this._teardown()}hasChanged(){return!1===this.lastValues||this.values.some((t,e)=>this.lastValues[e]!==t)}}),ot=nt(class extends tt{constructor(t,e,n){super(t,e),this.updater=this.updater.bind(this),this.makeArgs(n)}update(){return this.args}updater(t){if("function"==typeof t){const e=t,[n]=this.args;t=e(n)}this.makeArgs(t),this.el.update()}makeArgs(t){this.args=Object.freeze([t,this.updater])}}),at=(nt(class extends tt{constructor(t,e,n,r){super(t,e),this.dispatch=this.dispatch.bind(this),this.state=r}update(t){return this.reducer=t,[this.state,this.dispatch]}dispatch(t){this.state=this.reducer(this.state,t),this.el.update()}}),new WeakMap),ct=new WeakMap;class lt extends X{constructor(t,e){super(t,e),this.virtual=!0}commit(t){this.host.setValue(t),this.host.commit()}teardown(){super.teardown();let t=ct.get(this);at.delete(t)}}function ut(t){return s(function(...e){return n=>{let r=at.get(n);r||(r=new lt(t,n),at.set(n,r),ct.set(r,n),function t(e,n,r=n.startNode){let s=r.parentNode,i=new MutationObserver(s=>{for(let o of s){if(ht.call(o.removedNodes,r)){i.disconnect(),r.parentNode instanceof ShadowRoot?t(e,n):e.teardown();break}if(ht.call(o.addedNodes,r.nextSibling)){i.disconnect(),t(e,n,r.nextSibling);break}}});i.observe(s,{childList:!0})}(r,n)),r.args=e,r.update()}})}const ht=Array.prototype.includes;const dt=nt(class extends tt{constructor(t,e){super(t,e),function(t,e){F in t||(t[F]=[]),t[F].push(e)}(e,this),this._updater=this._updater.bind(this)}update(t){if(this.el.virtual)throw new Error("can't be used with virtual components");return this.Context!==t&&(this._subscribe(t),this.Context=t),this.value}_updater(t){this.value=t,this.el.update()}_subscribe(t){const e={Context:t,callback:this._updater};this.el.host.dispatchEvent(new CustomEvent("haunted.context",{detail:e,bubbles:!0,cancelable:!0,composed:!0}));const{unsubscribe:n,value:r}=e;this.value=n?r:t.defaultValue,this._unsubscribe=n}teardown(){this._unsubscribe&&this._unsubscribe()}});function pt(t,e){const n=t[e];try{return JSON.parse(n)}catch(t){console.warn(`Unable to parse key ${e}`,t)}return n}const ft=(t={})=>{const{uiSelectedInstance:e,tree:n,watchers:r}=t;if(!e)return{};const s={...n[e]};return s.state=pt(s,"state"),s.options=pt(s,"options"),{watchers:r.filter(t=>t.startsWith(`${e}:`)),...s}},gt=(t={})=>{const{watchers:e=[],tree:n={}}=t,r=e.sort().reduce((t,e)=>{const[r,s]=e.split(":");if(!t[r]){const{Component:e="unknown"}=n[r]||{};t[r]={keys:[],name:e,uid:r}}return t[r].keys.push(s),t},{});return Object.values(r)},mt=(t,e)=>t.watchers.some(t=>t.startsWith(`${e}:`)),vt=(t,e)=>({...t.tree[e]||{},selected:e===t.uiSelectedInstance,watched:mt(t,e)}),yt=(t=>{const e={};return e.Provider=class extends HTMLElement{constructor(){super(),this.listeners=[],this.eventHandler=(t=>{const{detail:n}=t;n.Context===e&&(n.value=this.value,n.unsubscribe=(()=>{const t=this.listeners.indexOf(n.callback);t>-1&&this.listeners.splice(t,1)}),this.listeners.push(n.callback),t.stopPropagation())}),this.addEventListener("haunted.context",this.eventHandler)}disconnectedCallback(){this.removeEventListener("haunted.context",this.eventHandler)}set value(t){this._value=t,this.listeners.forEach(e=>e(t))}get value(){return this._value}},e.Consumer=Z(function({render:t}){return t(dt(e))}),e.defaultValue=t,e})({});customElements.define("yzdt-state-provider",yt.Provider),customElements.define("yzdt-state-consumer",yt.Consumer);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const bt=(t,e)=>{const n=t.startNode.parentNode,r=void 0===e?t.endNode:e.startNode,s=n.insertBefore(v(),r);n.insertBefore(v(),r);const i=new S(t.options);return i.insertAfterNode(s),i},wt=(t,e)=>(t.setValue(e),t.commit(),t),xt=(t,e,n)=>{const r=t.startNode.parentNode,s=n?n.startNode:t.endNode,i=e.endNode.nextSibling;i!==s&&a(r,e.startNode,i,s)},kt=t=>{c(t.startNode.parentNode,t.startNode,t.endNode.nextSibling)},_t=(t,e,n)=>{const r=new Map;for(let s=e;s<=n;s++)r.set(t[s],s);return r},St=new WeakMap,zt=new WeakMap,$t=s((t,e,n)=>{let r;return void 0===n?n=e:void 0!==e&&(r=e),e=>{if(!(e instanceof S))throw new Error("repeat can only be used in text bindings");const s=St.get(e)||[],i=zt.get(e)||[],o=[],a=[],c=[];let l,u,h=0;for(const e of t)c[h]=r?r(e,h):h,a[h]=n(e,h),h++;let d=0,p=s.length-1,f=0,g=a.length-1;for(;d<=p&&f<=g;)if(null===s[d])d++;else if(null===s[p])p--;else if(i[d]===c[f])o[f]=wt(s[d],a[f]),d++,f++;else if(i[p]===c[g])o[g]=wt(s[p],a[g]),p--,g--;else if(i[d]===c[g])o[g]=wt(s[d],a[g]),xt(e,s[d],o[g+1]),d++,g--;else if(i[p]===c[f])o[f]=wt(s[p],a[f]),xt(e,s[p],s[d]),p--,f++;else if(void 0===l&&(l=_t(c,f,g),u=_t(i,d,p)),l.has(i[d]))if(l.has(i[p])){const t=u.get(c[f]),n=void 0!==t?s[t]:null;if(null===n){const t=bt(e,s[d]);wt(t,a[f]),o[f]=t}else o[f]=wt(n,a[f]),xt(e,n,s[d]),s[t]=null;f++}else kt(s[p]),p--;else kt(s[d]),d++;for(;f<=g;){const t=bt(e,o[g+1]);wt(t,a[f]),o[f++]=t}for(;d<=p;){const t=s[d++];null!==t&&kt(t)}St.set(e,o),zt.set(e,c)}}),Et=new WeakMap,Tt=s(t=>e=>{if(!(e instanceof S))throw new Error("unsafeHTML can only be used in text bindings");const n=Et.get(e);if(void 0!==n&&x(t)&&t===n.value&&e.value===n.fragment)return;const r=document.createElement("template");r.innerHTML=t;const s=document.importNode(r.content,!0);e.setValue(s),Et.set(e,{value:t,fragment:s})});
/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
window.navigator.userAgent.match("Trident")&&(DOMTokenList.prototype.toggle=function(t,e){return void 0===e||e?this.add(t):this.remove(t),void 0===e||e});const Ot=new WeakMap,Nt=new WeakMap,Ct=s(t=>e=>{if(!(e instanceof _)||e instanceof E||"class"!==e.committer.name||e.committer.parts.length>1)throw new Error("The `classMap` directive must be used in the `class` attribute and must be the only part in the attribute.");Nt.has(e)||(e.committer.element.className=e.committer.strings.join(" "),Nt.set(e,!0));const n=Ot.get(e);for(const r in n)r in t||e.committer.element.classList.remove(r);for(const r in t)n&&n[r]===t[r]||e.committer.element.classList.toggle(r,Boolean(t[r]));Ot.set(e,t)});var Pt=n(4),Gt=n.n(Pt),At=n(13),jt=n.n(At);const Mt=()=>{},Vt=t=>jt()(t)?{type:"object",value:"{...}",inspectable:!0}:Array.isArray(t)?{type:"array",value:`Array(${t.length})`,inspectable:!0}:"string"==typeof t?t.startsWith("[function ")?{type:"function",value:t}:{type:"string",value:t}:null==t?{type:"other",value:String(t)}:{type:"other",value:t},Dt=M`
  <style>
    .root {
      position: relative;
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      color: var(--color-quiet);
      font-family: var(--font-monospace);
      font-size: var(--font-size-m);
      padding-left: 1rem;
      line-height: 1.5em;
      cursor: default;
      user-select: none;
    }

    .expander {
      display: inline-block;
      width: 1rem;
      margin: -0.1em 0 0 -1rem;
      padding: 0;
      border: none;
      border-radius: 0;
      background: none;
      box-shadow: none;
      color: currentColor;
      font-size: 0.5rem;
      vertical-align: middle;
      text-align: center;
    }

    .expander::before {
      content: '\\25b6';
    }

    .expander[aria-expanded='true']::before {
      content: '\\25bc';
    }

    .children {
      flex-grow: 1;
      flex-basis: 100%;
    }

    .root::before {
      content: '$yuzu0';
      position: absolute;
      top: 0;
      left: calc(50% - 50vw);
      right: 0;
      z-index: -1;
      height: 1.5em;
      padding-right: 1em;
      background: var(--color-lighter);
      visibility: hidden;
      text-align: right;
      font-style: italic;
    }

    .isSelected::before {
      visibility: visible;
    }

    .watchMark {
      display: inline-block;
      width: 0.8em;
      height: 0.8em;
      margin-top: -1em;
      margin-right: 0.2em;
      vertical-align: super;
      fill: currentColor;
    }
  </style>
`,Lt=M`
  <style>
    :host {
      color: var(--color-accent);
    }

    span::after,
    span::before {
      color: var(--color-quiet);
    }

    span::after {
      content: '\\003e';
    }
    span::before {
      content: '\\003c';
    }

    :host([selfclose]) span::after {
      content: '\\002f\\003e';
    }

    :host([close]) span::before {
      content: '\\003c\\002f';
    }

    :host([watched]) {
      font-weight: bold;
    }
  </style>
`,It=["ref","detached"];function Wt(t){return It.map(e=>{const n=t[e];return n?M`
        <style>
        span {
          display: inline-block;
          color: var(--color-accent-ter);
        }
        b {
          color: var(--color-accent);
          font-weight: inherit;
        }
        </style>
        <span>
        ${e}${("boolean"==typeof n?"":n)?M`=<b>"${n}"</b>`:u}
        </span>`:u}).filter(t=>t)}function Rt(t={}){const{name:e,uid:n,expandable:r=!1,onClick:s=Mt,onSelect:i=Mt,expanded:o=!1,selected:a=!1,watched:c=!1,ref:l,detached:h}=t,d=c?M`<span
          class="watchMark"
          aria-label="Watching Component State"
          >${Tt(Gt.a)}</span
        >`:u,p=Ct({root:!0,isSelected:a});return M`
      ${Dt}
      <div class=${p}>
        ${r?M`<button
                type="button"
                class="expander"
                @click="${()=>s({uid:n,expanded:!o})}"
                aria-label="Expand / collapse children"
                aria-expanded="${o}"
              ></button>`:u}
        <yzdt-tag
          ?watched=${c}
          @click=${()=>i({uid:n})}
          ?selfclose=${!r}
        >${e}${d}<yzdt-attrs .ref=${l} ?detached=${h}></yzdt-attrs></yzdt-tag>
        ${r?M`
            <div class="children" ?hidden=${!o}>
              <slot></slot>
            </div>
            <yzdt-tag ?watched=${c} close>${e}</yzdt-tag>`:u}
      </div>
    `}Wt.observedAttributes=It,Wt.ATTRS=It,customElements.define("yzdt-attrs",Z(Wt)),customElements.define("yzdt-tag",Z(()=>M`
        ${Lt}<span><slot></slot></span>
      `)),Rt.observedAttributes=["name","uid","expanded","expandable","selected","ref","watched","detached"],customElements.define("yzdt-component",Z(Rt));var Ft=function(t,e){return Number(t.slice(0,-1*e.length))},Ht=function(t){return t.endsWith("px")?{value:t,type:"px",numeric:Ft(t,"px")}:t.endsWith("fr")?{value:t,type:"fr",numeric:Ft(t,"fr")}:t.endsWith("%")?{value:t,type:"%",numeric:Ft(t,"%")}:"auto"===t?{value:t,type:"auto"}:null},Bt=function(t){return t.split(" ").map(Ht)},qt=function(t,e,n){return e.concat(n).map(function(e){return e.style[t]}).filter(function(t){return void 0!==t&&""!==t})},Ut=function(t){for(var e=0;e<t.length;e++)if(t[e].numeric>0)return e;return null};function Qt(t){var e;return(e=[]).concat.apply(e,Array.from(t.ownerDocument.styleSheets).map(function(t){var e=[];try{e=Array.from(t.cssRules||[])}catch(t){}return e})).filter(function(e){var n=!1;try{n=t.matches(e.selectorText)}catch(t){}return n})}var Jt=function(){return!1},Yt=function(t,e,n){t.style[e]=n},Kt=function(t,e,n){var r=t[e];return void 0!==r?r:n},Xt=function(t,e,n){this.direction=t,this.element=e.element,this.track=e.track,this.trackTypes={},"column"===t?(this.gridTemplateProp="grid-template-columns",this.gridGapProp="grid-column-gap",this.cursor=Kt(n,"columnCursor",Kt(n,"cursor","col-resize")),this.snapOffset=Kt(n,"columnSnapOffset",Kt(n,"snapOffset",30)),this.dragInterval=Kt(n,"columnDragInterval",Kt(n,"dragInterval",1)),this.clientAxis="clientX",this.optionStyle=Kt(n,"gridTemplateColumns")):"row"===t&&(this.gridTemplateProp="grid-template-rows",this.gridGapProp="grid-row-gap",this.cursor=Kt(n,"rowCursor",Kt(n,"cursor","row-resize")),this.snapOffset=Kt(n,"rowSnapOffset",Kt(n,"snapOffset",30)),this.dragInterval=Kt(n,"rowDragInterval",Kt(n,"dragInterval",1)),this.clientAxis="clientY",this.optionStyle=Kt(n,"gridTemplateRows")),this.onDragStart=Kt(n,"onDragStart",Jt),this.onDragEnd=Kt(n,"onDragEnd",Jt),this.onDrag=Kt(n,"onDrag",Jt),this.writeStyle=Kt(n,"writeStyle",Yt),this.startDragging=this.startDragging.bind(this),this.stopDragging=this.stopDragging.bind(this),this.drag=this.drag.bind(this),this.minSizeStart=e.minSizeStart,this.minSizeEnd=e.minSizeEnd,e.element&&(this.element.addEventListener("mousedown",this.startDragging),this.element.addEventListener("touchstart",this.startDragging))};Xt.prototype.getDimensions=function(){var t=this.grid.getBoundingClientRect(),e=t.width,n=t.height,r=t.top,s=t.bottom,i=t.left,o=t.right;"column"===this.direction?(this.start=r,this.end=s,this.size=n):"row"===this.direction&&(this.start=i,this.end=o,this.size=e)},Xt.prototype.getSizeAtTrack=function(t,e){return function(t,e,n,r){void 0===n&&(n=0),void 0===r&&(r=!1);var s=r?t+1:t;return e.slice(0,s).reduce(function(t,e){return t+e.numeric},0)+(n?t*n:0)}(t,this.computedPixels,this.computedGapPixels,e)},Xt.prototype.getSizeOfTrack=function(t){return this.computedPixels[t].numeric},Xt.prototype.getRawTracks=function(){var t=qt(this.gridTemplateProp,[this.grid],Qt(this.grid));if(!t.length){if(this.optionStyle)return this.optionStyle;throw Error("Unable to determine grid template tracks from styles.")}return t[0]},Xt.prototype.getGap=function(){var t=qt(this.gridGapProp,[this.grid],Qt(this.grid));return t.length?t[0]:null},Xt.prototype.getRawComputedTracks=function(){return window.getComputedStyle(this.grid)[this.gridTemplateProp]},Xt.prototype.getRawComputedGap=function(){return window.getComputedStyle(this.grid)[this.gridGapProp]},Xt.prototype.setTracks=function(t){this.tracks=t.split(" "),this.trackValues=Bt(t)},Xt.prototype.setComputedTracks=function(t){this.computedTracks=t.split(" "),this.computedPixels=Bt(t)},Xt.prototype.setGap=function(t){this.gap=t},Xt.prototype.setComputedGap=function(t){var e,n;this.computedGap=t,this.computedGapPixels=(e="px",((n=this.computedGap).endsWith(e)?Number(n.slice(0,-1*e.length)):null)||0)},Xt.prototype.getMousePosition=function(t){return"touches"in t?t.touches[0][this.clientAxis]:t[this.clientAxis]},Xt.prototype.startDragging=function(t){if(!("button"in t&&0!==t.button)){t.preventDefault(),this.element?this.grid=this.element.parentNode:this.grid=t.target.parentNode,this.getDimensions(),this.setTracks(this.getRawTracks()),this.setComputedTracks(this.getRawComputedTracks()),this.setGap(this.getGap()),this.setComputedGap(this.getRawComputedGap());var e=this.trackValues.filter(function(t){return"%"===t.type}),n=this.trackValues.filter(function(t){return"fr"===t.type});if(this.totalFrs=n.length,this.totalFrs){var r=Ut(n);null!==r&&(this.frToPixels=this.computedPixels[r].numeric/n[r].numeric)}if(e.length){var s=Ut(e);null!==s&&(this.percentageToPixels=this.computedPixels[s].numeric/e[s].numeric)}var i=this.getSizeAtTrack(this.track,!1)+this.start;if(this.dragStartOffset=this.getMousePosition(t)-i,this.aTrack=this.track-1,!(this.track<this.tracks.length-1))throw Error("Invalid track index: "+this.track+". Track must be between two other tracks and only "+this.tracks.length+" tracks were found.");this.bTrack=this.track+1,this.aTrackStart=this.getSizeAtTrack(this.aTrack,!1)+this.start,this.bTrackEnd=this.getSizeAtTrack(this.bTrack,!0)+this.start,this.dragging=!0,window.addEventListener("mouseup",this.stopDragging),window.addEventListener("touchend",this.stopDragging),window.addEventListener("touchcancel",this.stopDragging),window.addEventListener("mousemove",this.drag),window.addEventListener("touchmove",this.drag),this.grid.addEventListener("selectstart",Jt),this.grid.addEventListener("dragstart",Jt),this.grid.style.userSelect="none",this.grid.style.webkitUserSelect="none",this.grid.style.MozUserSelect="none",this.grid.style.pointerEvents="none",this.grid.style.cursor=this.cursor,window.document.body.style.cursor=this.cursor,this.onDragStart(this.direction,this.track)}},Xt.prototype.stopDragging=function(){this.dragging=!1,this.cleanup(),this.onDragEnd(this.direction,this.track),this.needsDestroy&&(this.element&&(this.element.removeEventListener("mousedown",this.startDragging),this.element.removeEventListener("touchstart",this.startDragging)),this.destroyCb(),this.needsDestroy=!1,this.destroyCb=null)},Xt.prototype.drag=function(t){var e=this.getMousePosition(t),n=this.getSizeOfTrack(this.track),r=this.aTrackStart+this.minSizeStart+this.dragStartOffset+this.computedGapPixels,s=this.bTrackEnd-this.minSizeEnd-this.computedGapPixels-(n-this.dragStartOffset);e<r+this.snapOffset&&(e=r),e>s-this.snapOffset&&(e=s),e<r?e=r:e>s&&(e=s);var i=e-this.aTrackStart-this.dragStartOffset-this.computedGapPixels,o=this.bTrackEnd-e+this.dragStartOffset-n-this.computedGapPixels;if(this.dragInterval>1){var a=Math.round(i/this.dragInterval)*this.dragInterval;o-=a-i,i=a}if(i<this.minSizeStart&&(i=this.minSizeStart),o<this.minSizeEnd&&(o=this.minSizeEnd),"px"===this.trackValues[this.aTrack].type)this.tracks[this.aTrack]=i+"px";else if("fr"===this.trackValues[this.aTrack].type)if(1===this.totalFrs)this.tracks[this.aTrack]="1fr";else{var c=i/this.frToPixels;this.tracks[this.aTrack]=c+"fr"}else if("%"===this.trackValues[this.aTrack].type){var l=i/this.percentageToPixels;this.tracks[this.aTrack]=l+"%"}if("px"===this.trackValues[this.bTrack].type)this.tracks[this.bTrack]=o+"px";else if("fr"===this.trackValues[this.bTrack].type)if(1===this.totalFrs)this.tracks[this.bTrack]="1fr";else{var u=o/this.frToPixels;this.tracks[this.bTrack]=u+"fr"}else if("%"===this.trackValues[this.bTrack].type){var h=o/this.percentageToPixels;this.tracks[this.bTrack]=h+"%"}var d=this.tracks.join(" ");this.writeStyle(this.grid,this.gridTemplateProp,d),this.onDrag(this.direction,this.track,d)},Xt.prototype.cleanup=function(){window.removeEventListener("mouseup",this.stopDragging),window.removeEventListener("touchend",this.stopDragging),window.removeEventListener("touchcancel",this.stopDragging),window.removeEventListener("mousemove",this.drag),window.removeEventListener("touchmove",this.drag),this.grid&&(this.grid.removeEventListener("selectstart",Jt),this.grid.removeEventListener("dragstart",Jt),this.grid.style.userSelect="",this.grid.style.webkitUserSelect="",this.grid.style.MozUserSelect="",this.grid.style.pointerEvents="",this.grid.style.cursor=""),window.document.body.style.cursor=""},Xt.prototype.destroy=function(t,e){void 0===t&&(t=!0),t||!1===this.dragging?(this.cleanup(),this.element&&(this.element.removeEventListener("mousedown",this.startDragging),this.element.removeEventListener("touchstart",this.startDragging)),e&&e()):(this.needsDestroy=!0,e&&(this.destroyCb=e))};var Zt=function(t,e,n){return e in t?t[e]:n},te=function(t,e){return function(n){if(n.track<1)throw Error("Invalid track index: "+n.track+". Track must be between two other tracks.");var r="column"===t?e.columnMinSizes||{}:e.rowMinSizes||{},s="column"===t?"columnMinSize":"rowMinSize";return new Xt(t,Object.assign({},{minSizeStart:Zt(r,n.track-1,Kt(e,s,Kt(e,"minSize",0))),minSizeEnd:Zt(r,n.track+1,Kt(e,s,Kt(e,"minSize",0)))},n),e)}},ee=function(t){var e=this;this.columnGutters={},this.rowGutters={},this.options=Object.assign({},{columnGutters:t.columnGutters||[],rowGutters:t.rowGutters||[],columnMinSizes:t.columnMinSizes||{},rowMinSizes:t.rowMinSizes||{}},t),this.options.columnGutters.forEach(function(n){e.columnGutters[t.track]=te("column",e.options)(n)}),this.options.rowGutters.forEach(function(n){e.rowGutters[t.track]=te("row",e.options)(n)})};ee.prototype.addColumnGutter=function(t,e){this.columnGutters[e]&&this.columnGutters[e].destroy(),this.columnGutters[e]=te("column",this.options)({element:t,track:e})},ee.prototype.addRowGutter=function(t,e){this.rowGutters[e]&&this.rowGutters[e].destroy(),this.rowGutters[e]=te("row",this.options)({element:t,track:e})},ee.prototype.removeColumnGutter=function(t,e){var n=this;void 0===e&&(e=!0),this.columnGutters[t]&&this.columnGutters[t].destroy(e,function(){delete n.columnGutters[t]})},ee.prototype.removeRowGutter=function(t,e){var n=this;void 0===e&&(e=!0),this.rowGutters[t]&&this.rowGutters[t].destroy(e,function(){delete n.rowGutters[t]})},ee.prototype.handleDragStart=function(t,e,n){"column"===e?(this.columnGutters[n]&&this.columnGutters[n].destroy(),this.columnGutters[n]=te("column",this.options)({track:n}),this.columnGutters[n].startDragging(t)):"row"===e&&(this.rowGutters[n]&&this.rowGutters[n].destroy(),this.rowGutters[n]=te("row",this.options)({track:n}),this.rowGutters[n].startDragging(t))},ee.prototype.destroy=function(t){var e=this;void 0===t&&(t=!0),Object.keys(this.columnGutters).forEach(function(n){return e.columnGutters[n].destroy(t,function(){delete e.columnGutters[n]})}),Object.keys(this.rowGutters).forEach(function(n){return e.rowGutters[n].destroy(t,function(){delete e.rowGutters[n]})})};var ne=function(t){return new ee(t)};function re(t){const{uid:e,key:n,watched:r=!1}=t,s=function(t,e=Mt,n){return st(n=>{let r;({host:r}=n.currentTarget.getRootNode()),r&&r.dispatchEvent(new CustomEvent(t,{detail:e()}))},n)}("toggle",()=>({watched:!r}),[r]);return M`
    <style>
      :host {
        position: relative;
        display: inline-block;
        margin: -0.5em;
        margin-right: -0.4em;
        padding: 0.5em;
        box-sizing: content-box;
      }
      label {
        cursor: pointer;
      }
      svg {
        visibility: hidden;
        width: 1.25em;
        height: 1.5em;
        fill: var(--color-quiet);
        vertical-align: middle;
      }

      :hover > svg {
        visibility: visible;
      }

      input {
        position: absolute;
        overflow: hidden;
        width: 1px;
        height: 1px;
        padding: 0;
        white-space: nowrap;
        border: 0;
        clip-path: inset(50%);
      }

      :host([watched]) svg {
        visibility: visible;
        fill: var(--color-accent-secondary);
      }
    </style>
    <label title="Watch changes">
      <input
        type="checkbox"
        ?checked=${r}
        @click="${s}"
        value="${`${e}:${n}`}"
      />
      ${Tt(Gt.a)}
    </label>
  `}function se({key:t,uid:e,value:n,watchable:r=!1,watched:s=!1,onWatchChange:i=Mt}){const{type:o,value:a}=Vt(n);return M`
    <style>
      :host {
        display: flex;
        align-items: flex-start;
        padding: 0 var(--gutter) calc(var(--gutter) / 2);
        font-family: var(--font-monospace);
        font-size: var(--font-size-s);
        font-weight: normal;
      }
      .label {
        display: inline-block;
        padding-right: 0.5em;
        color: var(--color-accent-secondary);
        line-height: 1.5;
        flex-shrink: 1;
        flex-grow: 0;
      }

      :host(:not([watchable])) .label {
        padding-left: 1.4em;
      }

      .value {
        display: inline-block;
        font-family: var(--font-monospace);
        font-size: var(--font-size-s);
        font-weight: normal;
        line-height: 1.5;
        border: none;
        flex: 1 1 auto;
      }

      .value[data-type='string']::after,
      .value[data-type='string']::before {
        content: '\\0022';
        display: inline-block;
      }
    </style>
    ${r?M`
              <yzdt-watcher
                uid=${e}
                key=${t}
                ?watched=${s}
                @toggle=${({detail:n})=>i(e,t,n.watched)}
              ></yzdt-watcher>`:""}<span
      class="label"
      >${t}: </span
    ><span class="value" data-type=${o}>${a}</span>
  `}function ie({uid:t,name:e="",onSelect:n=Mt,props:r={},watchers:s=[],watchable:i=!1}){const o=i?M`
        <yzdt-watcher
          key="*"
          uid=${t}
          ?watched="${s.includes(`${t}:*`)}"
          @toggle=${({detail:e})=>n(t,"*",e.watched)}
        ></yzdt-watcher>
      `:"",a=Object.entries(r);return M`
    <style>
      :host {
        display: block;
      }
      :host(:not(:first-of-type)) {
        margin-top: var(--gutter);
        border-top: 1px solid var(--color-light);
      }

      .title {
        margin: var(--gutter);
        font-size: var(--font-size-m);
        font-weight: bold;
        line-height: 1.2;
      }

      .empty {
        margin: 0;
        padding: 0 var(--gutter);
        color: var(--color-quiet);
        font-size: var(--font-size-m);
        font-style: italic;
      }
    </style>
    <section>
      <h3 class="title"><span>${e}</span>&nbsp;${o}</h3>
      ${a.length?a.map(([e,r])=>M`
                <yzdt-prop
                  uid=${t}
                  key=${e}
                  .value=${r}
                  ?watchable=${i}
                  .onWatchChange=${n}
                  ?watched=${s.includes(`${t}:${e}`)}
                >
                </yzdt-prop>
              `):M`
            <p class="empty">empty object</p>
          `}
    </section>
  `}function oe(){const{watchers:t=[],onToggleWatch:e=Mt,onShow:n=Mt}=dt(yt);return M`
    <style>
      .group {
        padding: var(--gutter) var(--gutter) calc(var(--gutter) / 2);
      }
      .group:not(:first-child) {
        border-top: 1px solid var(--color-light);
      }
      p {
        margin: calc(var(--gutter) / 2) 0;
        padding: 0;
        font-family: var(--font-monospace);
        font-size: var(--font-size-s);
        font-weight: normal;
      }
      b {
        color: var(--color-accent);
        font-weight: normal;
      }
      header {
        display: flex;
        align-items: baseline;
      }
      h3 {
        margin: 0;
        font-size: var(--font-size-m);
      }
      .btn {
        margin-left: 0.5em;
        padding: 0;
        border: 0;
        background-color: none;
        text-decoration: underline;
        color: var(--color-accent);
        font-size: var(--font-size-s);
        cursor: pointer;
      }
    </style>
    <yzdt-side-panel>
      ${0===t.length?M`
            <yzdt-blank-slate slot="body"
              >No watchers listening</yzdt-blank-slate
            >
          `:M`
            <div class="wrap" slot="body">
              ${t.map(({uid:t,keys:r=[],name:s})=>M`
                  <div class="group">
                    <header>
                      <h3>${s}#${t}</h3>
                      <button
                        type="button"
                        class="btn"
                        @click=${()=>n({uid:t})}
                      >
                        show
                      </button>
                    </header>
                    ${r.map(n=>M`
                        <p>
                          <yzdt-watcher
                            key=${n}
                            uid=${t}
                            ?watched=${!0}
                            @toggle=${()=>e(t,n,!1)}
                          ></yzdt-watcher>
                          <b>${"*"===n?"<all>":n}</b>
                        </p>
                      `)}
                  </div>
                `)}
            </div>
          `}
    </yzdt-side-panel>
  `}customElements.define("yzdt-panels",Z(function(){const t=document.createElement("div");return t.className="gutter",it(()=>{ne({gridTemplateColumns:"1fr 6px 0.5fr",columnGutters:[{track:1,element:t}]})},[t]),M`
    <style>
      :host {
        display: block;
      }
      .root {
        display: grid;
        height: 100vh;
        grid-template-columns: 1fr 6px 0.5fr;
        grid-template-rows: 1fr;
        grid-template-areas: 'main gutter side';
      }

      ::slotted([slot='main']) {
        grid-area: main;
        min-height: 0;
        border-right: 1px solid var(--color-light);
      }

      ::slotted([slot='side']) {
        grid-area: side;
        min-height: 0;
        border-left: 1px solid var(--color-light);
      }

      ::slotted([slot]) > * {
        height: 100%;
      }

      .gutter {
        grid-area: gutter;
        background: var(--color-lighter);
        background-image: linear-gradient(
          to top,
          var(--color-quiet),
          var(--color-quiet)
        );
        background-repeat: no-repeat;
        background-position: center center;
        background-size: 2px 30px;
      }
    </style>
    <div class="root">
      <slot name="main"></slot> ${t} <slot name="side"></slot>
      <div></div>
    </div>
  `})),customElements.define("yzdt-main-panel",Z(function(){return M`
    <style>
      :host {
        display: block;
        overflow: auto;
        height: 100%;
      }
    </style>
    <div><slot></slot></div>
  `})),customElements.define("yzdt-side-panel",Z(function(){return M`
    <style>
      :host {
        display: grid;
        grid-template-rows: auto 1fr;
        grid-template-columns: 1fr;
        grid-template-areas: 'header' 'wrap';
        height: 100%;
      }
      [slot='header'] {
        grid-area: header;
      }

      .panelWrap {
        grid-area: wrap;
        overflow-y: auto;
        min-height: 0;
        padding-bottom: var(--gutter);
      }
    </style>
    <slot name="header"></slot>
    <div class="panelWrap">
      <slot name="body"></slot>
    </div>
  `})),customElements.define("yzdt-blank-slate",Z(function(){return M`
    <style>
      .blank {
        margin: 0;
        padding: var(--gutter);
        color: var(--color-quiet);
        font-size: var(--font-size-m);
        font-style: italic;
      }
    </style>
    <p class="blank"><slot></slot></p>
  `})),re.observedAttributes=["watched","uid","key"],customElements.define("yzdt-watcher",Z(re)),se.observedAttributes=["key","uid","value","watched","watchable"],customElements.define("yzdt-prop",Z(se)),ie.observedAttributes=["name","uid","watched","watchable","watchers","props"],customElements.define("yzdt-prop-list",Z(ie)),customElements.define("yzdt-element-panel",Z(function(){const{Component:t,uid:e,options:n={},state:r={},watchers:s,onPropCheck:i}=dt(yt);return M`
    <style>
      .title {
        margin: 0;
        padding: 8px var(--gutter);
        font-size: var(--font-size-l);
        font-weight: bold;
        line-height: 1.2;
        background-color: var(--color-lighter);
      }

      .title > em {
        font-size: 0.75em;
      }
    </style>
    <yzdt-side-panel>
      ${e?M`
            <h2 slot="header" class="title">
              ${t||"Component"}<em>#${e}</em>
            </h2>
            <div slot="body">
              <yzdt-prop-list name="Options" .props=${n}></yzdt-prop-list>
              <yzdt-prop-list
                name="State"
                uid=${e}
                ?watchable=${!0}
                .onSelect=${i}
                .props=${r}
                .watchers=${s}
              ></yzdt-prop-list>
            </div>
          `:M`
            <yzdt-blank-slate slot="body"
              >Select a component on the left panel to inspect its
              properties</yzdt-blank-slate
            >
          `}
    </yzdt-side-panel>
  `})),oe.observedAttributes=["name","uid"],customElements.define("yzdt-watchers-panel",Z(oe));var ae=M`
  <style>
    :host {
      display: grid;
      grid-template-columns: 1fr;
      grid-template-rows: auto 1fr;
      grid-template-areas: 'tabs' 'tabpanels';
    }
    ul {
      grid-area: tabs;
      list-style-type: none;
      margin: 0;
      padding: 0;
    }
    ul {
      display: flex;
      margin: 0;
      padding: 0;
      border-bottom: 1px solid var(--color-light);
      font-size: var(--font-size-m);
      font-weight: bold;
      line-height: 1.2;
      background-color: var(--color-lighter);
    }
    a[role='tab'] {
      display: inline-block;
      padding: calc(var(--gutter) / 2) var(--gutter);
      text-decoration: none;
      color: var(--color-dark);
      font-weight: normal;
    }

    a[aria-selected='true'] {
      background: linear-gradient(
          to top,
          var(--color-quiet),
          var(--color-quiet)
        )
        no-repeat 0 bottom;
      background-size: 100% 1px;
      font-weight: bold;
    }

    a[role='tab'] sup {
      vertical-align: baseline;
      position: relative;
      top: -0.4em;
    }

    section[role='tabpanel'] {
      grid-area: tabpanels;
      min-height: 0;
    }
  </style>
`;customElements.define("yzdt-tabs",Z(function({tabs:t=[]}){const[e,n]=ot(t[0].id);return M`
    ${ae}
    <ul role="tablist">
      ${t.map(({label:t,id:r})=>M`
          <li role="presentation">
            <a
              role="tab"
              href="#${r}-panel"
              id="${r}-tab"
              aria-selected=${e===r}
              @click=${t=>t.preventDefault()||n(r)}
              >${Tt(t)}</a
            >
          </li>
        `)}
    </ul>
    ${t.map(({id:t})=>M`
        <section
          role="tabpanel"
          id="${t}-panel"
          aria-labelledby="${t}-tab"
          ?hidden=${e!==t}
        >
          <slot name="${t}"></slot>
        </section>
      `)}
  `}));const ce=M`
  <style>
    :root {
      --color-accent: rgb(136, 18, 128);
      --color-accent-secondary: rgb(200, 0, 0);
      --color-accent-ter: rgb(153, 69, 0);
      --color-quiet: rgb(136, 136, 136);
      --color-light: rgb(218, 218, 218);
      --color-dark: #333;
      --color-lighter: #efefef;
      --gutter: 16px;
      --font-size-s: 0.75rem;
      --font-size-m: 0.875rem;
      --font-size-l: 1rem;
      --font-default: sans-serif;
      --font-monospace: Menlo, Consolas, monospace;
    }
    * {
      box-sizing: border-box;
    }
    *::before,
    *::after {
      box-sizing: inherit;
    }
    html,
    body {
      height: 100vh;
      overflow: hidden;
      margin: 0;
      padding: 0;
      font-family: var(--font-default);
      font-size: 100%;
      color: var(--color-dark);
    }
  </style>
`;var le={get(t){try{return JSON.parse(localStorage.getItem(t))}catch(t){}},set(t,e){try{localStorage.setItem(t,JSON.stringify(e))}catch(t){}},remove(t){try{localStorage.removeItem(t)}catch(t){}},clear(){try{localStorage.clear()}catch(t){}}};var ue=[(t,{type:e,action:n})=>{if("hooks:init"===e){const{roots:e}=t,r={...t.tree,[n.uid]:Object.assign({},t.tree[n.uid],n)};if(n.parent){const e=r[n.parent]||{};return r[n.parent]={...e,childIds:(e.childIds||[]).concat(n.uid)},{...t,tree:r}}return{...t,roots:[...e,n.uid],tree:r}}return t},(t,{type:e,action:n})=>{if("hooks:destroy"===e){const{roots:e}=t,{uid:r}=n,s={...t.tree};return delete s[r],e.includes(r)?{...t,tree:s,roots:e.filter(t=>t!==r)}:(Object.keys(s).some(t=>{const e=s[t];return!(!e.childIds||!e.childIds.includes(r)||(s[t]={...e,childIds:e.childIds.filter(t=>t!==r)},0))}),{...t,tree:s})}return t},(t,{type:e,action:n})=>{switch(e){case"ui:expand":{const{uid:e,expanded:r}=n,s={...t.tree[e],expanded:r};return{...t,tree:{...t.tree,[e]:s}}}case"ui:watchstate":{const{uid:e,key:r,watched:s}=n;let i=[...t.watchers];const o=`${e}:${r}`,a=i.indexOf(o);return s||-1===a?s&&-1!==a?t:("*"===r&&(i=i.filter(t=>!1===t.startsWith(`${e}:`))),i.push(o),{...t,watchers:i}):(i.splice(a,1),{...t,watchers:i})}case"ui:select":return{...t,uiSelectedInstance:n.uid};case"ui:inspect":{const{tree:e}=t,{uid:r}=n;let{parent:s}=e[r];for(;s;)e[s]={...e[s],expanded:!0},({parent:s}=e[s]);return{...t,tree:{...e},uiSelectedInstance:r}}default:return t}},(t,{type:e,action:n})=>{if("hooks:statechange"===e){const{uid:e}=n,r={...t.tree};return r[e]={...r[e],state:n.state},{...t,tree:r}}return t}];var he=t=>({expandBranch(e){t.action({type:"ui:expand",action:e})},removeChild(e){t.action({type:"hooks:destroy",action:e})},updateState(e){t.action({type:"hooks:statechange",action:e})},selectInstance(e){t.action({type:"ui:select",action:e})},inspectInstance(e){t.action({type:"ui:inspect",action:e})},toggleWatcher(e){t.action({type:"ui:watchstate",action:e})}}),de=n(9),pe=n.n(de);const fe=function(t={},e=[],n=[]){const r=[];function s(t){return n.reduce((t,e)=>{const n=le.get(e);return null!=n&&(t[e]=n),t},t)}let i=s(t);return{action(t={}){const s=i;(i=e.reduce((e,n)=>n(e,t),i))!==s&&(r.forEach(e=>e(this.getState(),s,t)),n.forEach(t=>{i[t]!==s[t]&&le.set(t,i[t])}))},getState:()=>i,resetState(){i=s(t)},subscribe(t){r.push(t)}}}({tree:{},roots:[],uiSelectedInstance:null,watchers:[]},ue,["watchers"]),ge=he(fe),me=(t=>(e,n,{type:r,action:s}={})=>{r&&t[r]&&t[r](e,n,s)})((t=>({"ui:watchstate":function(e,n){const r=pe()(n.watchers,e.watchers),s=pe()(e.watchers,n.watchers);r.length>0&&r.forEach(e=>t("logEnd",e)),s.length>0&&s.forEach(e=>t("logStart",e))},"hooks:init":function({watchers:e},n,{uid:r}){const s=r&&`${r}:`;s&&e.forEach(e=>{e.startsWith(s)&&t("logStart",e)})},"ui:select":function({uiSelectedInstance:e}){t("setGlobal",e),t("setCurrent",e)},"yuzu:panel-hidden":function(){t("stop")}}))((t,...e)=>{const n=e.map(t=>"string"==typeof t?`"${t}"`:t).join(", ");chrome.devtools.inspectedWindow.eval(`window.__YUZU_DEVTOOLS_GLOBAL_HOOK__.${t}(${n})`)})),ve=function({container:t,actions:e={}}){const n={onClick:e.expandBranch,onSelect:e.selectInstance},r=(t,n,r)=>e.toggleWatcher({uid:t,key:n,watched:r}),s=t.parentElement,i=document.createDocumentFragment();j(ce,i),s.prepend(i);const o=ut(({state:t,treeRenderer:n})=>{const{watchers:s,tree:i,roots:o,uiSelectedInstance:a}=t,c=rt(()=>[{id:"element",label:"Element"},{id:"watchers",label:`Watchers${s.length?`<sup>(${s.length})</sup>`:""}`}],[s.length]),l=rt(()=>({...ft(t),onPropCheck:r}),[s,i[a]]),u=rt(()=>({watchers:gt(t),onShow:e.inspectInstance,onToggleWatch:r}),[s]);return M`
      <yzdt-panels>
        <yzdt-main-panel slot="main">
          ${n(o,t)}
        </yzdt-main-panel>
        <yzdt-tabs slot="side" .tabs=${c}>
          <yzdt-state-provider slot="element" .value=${l}>
            <yzdt-element-panel></yzdt-element-panel>
          </yzdt-state-provider>
          <yzdt-state-provider slot="watchers" .value=${u}>
            <yzdt-watchers-panel></yzdt-watchers-panel>
          </yzdt-state-provider> </yzdt-tabs
      ></yzdt-panels>
    `}),a=function({actions:t,getData:e=(()=>({}))}){return function n(r,s){return M`
      ${$t(r,t=>t,r=>{const{Component:i,uid:o,childIds:a,expanded:c=!1,selected:l=!1,watched:h=!1,ref:d,detached:p}=e(s,r),{onClick:f,onSelect:g}=t,m=Array.isArray(a)&&a.length>0;return M`
            <yzdt-component
              name=${i}
              uid=${o}
              .ref=${d}
              ?detached=${p}
              ?expandable=${m}
              ?expanded=${c}
              ?selected=${l}
              ?watched=${h}
              .onClick=${f}
              .onSelect=${g}
              >${m?n(a,s):u}</yzdt-component
            >
          `})}
    `}}({actions:n,getData:vt});return{render(e){j(o({state:e,treeRenderer:a}),t)}}}({container:document.querySelector("#container"),actions:ge});fe.subscribe(t=>ve.render(t)),fe.subscribe(me);const ye=chrome.runtime.connect({name:`${chrome.devtools.inspectedWindow.tabId}`});chrome.devtools.network.onNavigated.addListener(()=>{fe.resetState(),ye.postMessage({type:"ui:initialize"})}),ye.postMessage({type:"ui:initialize"}),ye.onMessage.addListener((t={})=>{fe.action(t)})}]);
//# sourceMappingURL=panel.js.map